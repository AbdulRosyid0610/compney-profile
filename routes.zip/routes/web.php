<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('halaman awal');
});

Route::get('/Fasilitas', function () {
    return view('Fasilitas');
})->name('Fasilitas');

Route::get('/kamar', function () {
    return view('kamar');
})->name('kamar');

Route::get('/Tentang agria', function () {
    return view('Tentang agria');
})->name('Tentang agria');

Route::get('/Kontak', function () {
    return view('Kontak');
})->name('Kontak');

Route::get('/pemesanan', function () {
    return view('pemesanan');
})->name('pemesanan');