<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kamar - Hotel Agria Bogor</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        /* Header */
        header {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 0;
        }

        .logo {
            font-size: 1.5rem;
            font-weight: bold;
            color: #4a90e2;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .logo::before {
            content: "🏨";
            font-size: 1.8rem;
        }

        .nav-links {
            display: flex;
            list-style: none;
            gap: 2rem;
        }

        .nav-links a {
            text-decoration: none;
            color: #333;
            font-weight: 500;
            transition: all 0.3s ease;
            position: relative;
            padding: 5px 0;
        }

        .nav-links a:hover {
            color: #4a90e2;
            transform: translateY(-2px);
        }

        .nav-links a.active {
            color: #4a90e2;
        }

        .nav-links a::after {
            content: '';
            position: absolute;
            width: 0;
            height: 2px;
            bottom: 0;
            left: 0;
            background: #4a90e2;
            transition: width 0.3s ease;
        }

        .nav-links a:hover::after,
        .nav-links a.active::after {
            width: 100%;
        }

        /* Hero Section */
        .hero {
            background: linear-gradient(rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.4)),
                        url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 600"><rect fill="%23667eea" width="1200" height="600"/><circle cx="200" cy="150" r="100" fill="%23764ba2" opacity="0.3"/><circle cx="800" cy="400" r="150" fill="%2356ab2f" opacity="0.2"/><circle cx="1000" cy="100" r="80" fill="%23ff6b6b" opacity="0.3"/></svg>');
            background-size: cover;
            background-position: center;
            color: white;
            text-align: center;
            padding: 6rem 0;
            margin-bottom: 4rem;
        }

        .hero h1 {
            font-size: 3rem;
            margin-bottom: 1rem;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
        }

        .hero p {
            font-size: 1.2rem;
            max-width: 600px;
            margin: 0 auto;
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.3);
        }

        /* Room Types Section */
        .rooms-section {
            padding: 4rem 0;
        }

        .section-title {
            text-align: center;
            font-size: 2.5rem;
            color: white;
            margin-bottom: 3rem;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
        }

        .rooms-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 2rem;
            margin-bottom: 4rem;
        }

        .room-card {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            transition: all 0.3s ease;
            backdrop-filter: blur(10px);
        }

        .room-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
        }

        .room-image {
            height: 250px;
            background: linear-gradient(45deg, #667eea, #764ba2);
            position: relative;
            overflow: hidden;
        }

        .room-image::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 250"><rect fill="%23f8f9fa" width="400" height="250"/><rect x="50" y="50" width="120" height="80" fill="%23dee2e6" rx="10"/><rect x="200" y="40" width="100" height="60" fill="%23adb5bd" rx="5"/><circle cx="320" cy="60" r="20" fill="%236c757d"/><rect x="50" y="160" width="300" height="40" fill="%23495057" rx="20"/></svg>');
            background-size: cover;
            opacity: 0.8;
        }

        .room-badge {
            position: absolute;
            top: 15px;
            right: 15px;
            background: rgba(255, 255, 255, 0.9);
            color: #4a90e2;
            padding: 5px 15px;
            border-radius: 20px;
            font-weight: bold;
            font-size: 0.9rem;
        }

        .room-content {
            padding: 2rem;
        }

        .room-title {
            font-size: 1.5rem;
            font-weight: bold;
            color: #333;
            margin-bottom: 1rem;
        }

        .room-description {
            color: #666;
            margin-bottom: 1.5rem;
            line-height: 1.6;
        }

        .room-features {
            display: flex;
            flex-wrap: wrap;
            gap: 0.5rem;
            margin-bottom: 1.5rem;
        }

        .feature-tag {
            background: #e3f2fd;
            color: #1976d2;
            padding: 5px 12px;
            border-radius: 15px;
            font-size: 0.9rem;
            font-weight: 500;
        }

        .room-price {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
        }

        .price {
            font-size: 1.8rem;
            font-weight: bold;
            color: #4a90e2;
        }

        .price-subtitle {
            font-size: 0.9rem;
            color: #666;
        }

        .book-btn {
            width: 100%;
            background: linear-gradient(45deg, #4a90e2, #667eea);
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 25px;
            font-size: 1.1rem;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(74, 144, 226, 0.3);
        }

        .book-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(74, 144, 226, 0.4);
        }

        /* Facilities Section */
        .facilities-section {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 3rem;
            margin: 4rem 0;
        }

        .facilities-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 2rem;
        }

        .facility-item {
            text-align: center;
            color: white;
            padding: 1.5rem;
            border-radius: 15px;
            background: rgba(255, 255, 255, 0.1);
            transition: all 0.3s ease;
        }

        .facility-item:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: translateY(-5px);
        }

        .facility-icon {
            font-size: 3rem;
            margin-bottom: 1rem;
        }

        .facility-title {
            font-size: 1.2rem;
            font-weight: bold;
            margin-bottom: 0.5rem;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .nav-links {
                flex-direction: column;
                gap: 1rem;
            }

            .hero h1 {
                font-size: 2rem;
            }

            .hero p {
                font-size: 1rem;
            }

            .section-title {
                font-size: 2rem;
            }

            .rooms-grid {
                grid-template-columns: 1fr;
            }

            .facilities-section {
                padding: 2rem;
            }
        }

        /* Animation */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .room-card {
            animation: fadeInUp 0.6s ease forwards;
        }

        .room-card:nth-child(2) {
            animation-delay: 0.1s;
        }

        .room-card:nth-child(3) {
            animation-delay: 0.2s;
        }

        .room-card:nth-child(4) {
            animation-delay: 0.3s;
        }
    </style>
</head>
<body>
    <header>
        <nav class="container">
            <div class="logo">Hotel Agria Bogor</div>
            <ul class="nav-links">
                 <li><a href="/">Beranda</a></li>
                    <li><a href="/kamar">Kamar</a></li>
                    <li><a href="/Fasilitas">Fasilitas</a></li>
                    <li><a href="/pemesanan">Pemesanan</a></li>
                    <li><a href="/Kontak" class="active">Kontak</a></li>
            </ul>
        </nav>
    </header>

    <section class="hero">
        <div class="container">
            <h1>Kamar & Suite</h1>
            <p>Pilih kamar yang sesuai dengan kebutuhan Anda untuk pengalaman menginap yang tak terlupakan</p>
        </div>
    </section>

    <section class="rooms-section">
        <div class="container">
            <h2 class="section-title">Tipe Kamar Tersedia</h2>
            
            <div class="rooms-grid">
                <!-- Standard Room -->
                <div class="room-card">
                    <div class="room-image">
                        <div class="room-badge">Populer</div>
                    </div>
                    <div class="room-content">
                        <h3 class="room-title">Kamar Standard</h3>
                        <p class="room-description">Kamar nyaman dengan fasilitas lengkap untuk menginap yang menyenangkan. Dilengkapi dengan tempat tidur queen size dan pemandangan taman.</p>
                        <div class="room-features">
                            <span class="feature-tag">🛏️ Queen Bed</span>
                            <span class="feature-tag">🌡️ AC</span>
                            <span class="feature-tag">📺 TV LED</span>
                            <span class="feature-tag">🚿 Kamar Mandi</span>
                            <span class="feature-tag">📶 WiFi</span>
                        </div>
                        <div class="room-price">
                            <div>
                                <div class="price">Rp 450K</div>
                                <div class="price-subtitle">per malam</div>
                            </div>
                        </div>
                        <button class="book-btn" onclick="bookRoom('Standard')">Pesan Sekarang</button>
                    </div>
                </div>

                <!-- Deluxe Room -->
                <div class="room-card">
                    <div class="room-image">
                        <div class="room-badge">Terbaik</div>
                    </div>
                    <div class="room-content">
                        <h3 class="room-title">Kamar Deluxe</h3>
                        <p class="room-description">Kamar luas dengan fasilitas premium dan pemandangan kota Bogor yang menawan. Dilengkapi dengan area duduk yang nyaman.</p>
                        <div class="room-features">
                            <span class="feature-tag">🛏️ King Bed</span>
                            <span class="feature-tag">🛋️ Sofa</span>
                            <span class="feature-tag">🌡️ AC</span>
                            <span class="feature-tag">📺 Smart TV</span>
                            <span class="feature-tag">☕ Mini Bar</span>
                            <span class="feature-tag">🌅 City View</span>
                        </div>
                        <div class="room-price">
                            <div>
                                <div class="price">Rp 650K</div>
                                <div class="price-subtitle">per malam</div>
                            </div>
                        </div>
                        <button class="book-btn" onclick="bookRoom('Deluxe')">Pesan Sekarang</button>
                    </div>
                </div>

                <!-- Suite Room -->
                <div class="room-card">
                    <div class="room-image">
                        <div class="room-badge">Mewah</div>
                    </div>
                    <div class="room-content">
                        <h3 class="room-title">Suite Premium</h3>
                        <p class="room-description">Suite mewah dengan ruang terpisah untuk tidur dan bersantai. Fasilitas terlengkap dengan layanan room service 24 jam.</p>
                        <div class="room-features">
                            <span class="feature-tag">🛏️ King Bed</span>
                            <span class="feature-tag">🛋️ Living Room</span>
                            <span class="feature-tag">🛁 Bathtub</span>
                            <span class="feature-tag">🍾 Mini Bar</span>
                            <span class="feature-tag">🌆 Balcony</span>
                            <span class="feature-tag">🍽️ Room Service</span>
                        </div>
                        <div class="room-price">
                            <div>
                                <div class="price">Rp 950K</div>
                                <div class="price-subtitle">per malam</div>
                            </div>
                        </div>
                        <button class="book-btn" onclick="bookRoom('Suite')">Pesan Sekarang</button>
                    </div>
                </div>

                <!-- Family Room -->
                <div class="room-card">
                    <div class="room-image">
                        <div class="room-badge">Keluarga</div>
                    </div>
                    <div class="room-content">
                        <h3 class="room-title">Kamar Keluarga</h3>
                        <p class="room-description">Kamar luas yang sempurna untuk keluarga dengan 2 tempat tidur terpisah. Cocok untuk liburan bersama keluarga tercinta.</p>
                        <div class="room-features">
                            <span class="feature-tag">🛏️ 2 Double Beds</span>
                            <span class="feature-tag">👨‍👩‍👧‍👦 Max 4 Orang</span>
                            <span class="feature-tag">🎮 Kids Corner</span>
                            <span class="feature-tag">📺 TV LED</span>
                            <span class="feature-tag">🚿 Double Sink</span>
                            <span class="feature-tag">🅿️ Free Parking</span>
                        </div>
                        <div class="room-price">
                            <div>
                                <div class="price">Rp 750K</div>
                                <div class="price-subtitle">per malam</div>
                            </div>
                        </div>
                        <button class="book-btn" onclick="bookRoom('Family')">Pesan Sekarang</button>
                    </div>
                </div>
            </div>

            <!-- Hotel Facilities -->
            <div class="facilities-section">
                <h2 class="section-title">Fasilitas Hotel</h2>
                <div class="facilities-grid">
                    <div class="facility-item">
                        <div class="facility-icon">🏊‍♂️</div>
                        <div class="facility-title">Kolam Renang</div>
                        <p>Kolam renang outdoor dengan pemandangan indah</p>
                    </div>
                    <div class="facility-item">
                        <div class="facility-icon">🍽️</div>
                        <div class="facility-title">Restaurant</div>
                        <p>Restoran dengan menu lokal dan internasional</p>
                    </div>
                    <div class="facility-item">
                        <div class="facility-icon">💪</div>
                        <div class="facility-title">Fitness Center</div>
                        <p>Pusat kebugaran dengan peralatan modern</p>
                    </div>
                    <div class="facility-item">
                        <div class="facility-icon">🅿️</div>
                        <div class="facility-title">Parking</div>
                        <p>Area parkir luas dan aman untuk tamu</p>
                    </div>
                    <div class="facility-item">
                        <div class="facility-icon">📶</div>
                        <div class="facility-title">Free WiFi</div>
                        <p>Koneksi internet gratis di seluruh area hotel</p>
                    </div>
                    <div class="facility-item">
                        <div class="facility-icon">🛎️</div>
                        <div class="facility-title">Concierge</div>
                        <p>Layanan concierge 24 jam untuk keperluan Anda</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script>
        function bookRoom(roomType) {
            // Simple booking alert (in real implementation, this would redirect to booking page)
            alert(`Anda akan melakukan pemesanan untuk ${roomType} Room. Redirecting ke halaman pemesanan...`);
            
            // Add some visual feedback
            event.target.innerHTML = '✓ Memproses...';
            event.target.style.background = '#4caf50';
            
            setTimeout(() => {
                event.target.innerHTML = 'Pesan Sekarang';
                event.target.style.background = 'linear-gradient(45deg, #4a90e2, #667eea)';
            }, 2000);
        }

        // Add scroll animation
        window.addEventListener('scroll', () => {
            const cards = document.querySelectorAll('.room-card');
            cards.forEach(card => {
                const cardTop = card.getBoundingClientRect().top;
                const windowHeight = window.innerHeight;
                
                if (cardTop < windowHeight - 100) {
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                }
            });
        });

        // Add hover effects for room cards
        document.querySelectorAll('.room-card').forEach(card => {
            card.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-15px) scale(1.02)';
            });
            
            card.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(0) scale(1)';
            });
        });
    </script>
</body>
</html>