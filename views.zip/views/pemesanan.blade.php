<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hotel Agria Bogor - Pemesanan</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
            color: #333;
        }

        .header {
            background-color: white;
            padding: 15px 0;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        .nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            display: flex;
            align-items: center;
            color: #007bff;
            font-size: 20px;
            font-weight: bold;
        }

        .logo::before {
            content: "🏨";
            margin-right: 10px;
        }

        .nav-menu {
            display: flex;
            list-style: none;
            gap: 30px;
        }

        .nav-menu a {
            text-decoration: none;
            color: #666;
            font-weight: 500;
            transition: color 0.3s;
        }

        .nav-menu a:hover {
            color: #007bff;
        }

        .main-content {
            padding: 50px 0;
        }

        .booking-section {
            background-color: white;
            border-radius: 10px;
            padding: 40px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            max-width: 800px;
            margin: 0 auto;
        }

        .section-title {
            text-align: center;
            font-size: 28px;
            color: #333;
            margin-bottom: 30px;
            position: relative;
        }

        .section-title::after {
            content: '';
            position: absolute;
            bottom: -10px;
            left: 50%;
            transform: translateX(-50%);
            width: 80px;
            height: 3px;
            background-color: #ffc107;
        }

        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 20px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
        }

        .form-group.full-width {
            grid-column: 1 / -1;
        }

        label {
            margin-bottom: 8px;
            font-weight: 500;
            color: #555;
        }

        input[type="text"],
        input[type="email"],
        input[type="tel"],
        input[type="date"],
        select,
        textarea {
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
            transition: border-color 0.3s;
        }

        input[type="text"]:focus,
        input[type="email"]:focus,
        input[type="tel"]:focus,
        input[type="date"]:focus,
        select:focus,
        textarea:focus {
            outline: none;
            border-color: #007bff;
            box-shadow: 0 0 0 2px rgba(0,123,255,0.25);
        }

        select {
            cursor: pointer;
            background-color: white;
        }

        textarea {
            resize: vertical;
            min-height: 100px;
        }

        .submit-btn {
            background-color: #ffc107;
            color: #333;
            border: none;
            padding: 15px 30px;
            border-radius: 5px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s;
            display: block;
            margin: 30px auto 0;
            min-width: 200px;
        }

        .submit-btn:hover {
            background-color: #e0a800;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(255,193,7,0.4);
        }

        .submit-btn::before {
            content: "📧 ";
            margin-right: 8px;
        }

        @media (max-width: 768px) {
            .nav-menu {
                display: none;
            }
            
            .form-grid {
                grid-template-columns: 1fr;
            }
            
            .booking-section {
                margin: 20px;
                padding: 30px 20px;
            }
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="container">
            <nav class="nav">
                <div class="logo">Hotel Agria Bogor</div>
                <ul class="nav-menu">
                    <li><a href="/">beranda</a></li>
                    <li><a href="/kamar">Kamar</a></li>
                    <li><a href="/Fasilitas">Fasilitas</a></li>
                    <li><a href="/pemesanan">Pemesanan</a></li>
                    <li><a href="/Kontak">Kontak</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main class="main-content">
        <div class="container">
            <section class="booking-section">
                <h2 class="section-title">Pesan Kamar Sekarang</h2>
                
                <form id="bookingForm">
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="namaLengkap">Nama Lengkap</label>
                            <input type="text" id="namaLengkap" name="namaLengkap" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" id="email" name="email" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="noTelepon">No. Telepon</label>
                            <input type="tel" id="noTelepon" name="noTelepon" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="tipeKamar">Tipe Kamar</label>
                            <select id="tipeKamar" name="tipeKamar" required>
                                <option value="">Pilih Tipe Kamar</option>
                                <option value="standard">Standard Room</option>
                                <option value="deluxe">Deluxe Room</option>
                                <option value="suite">Suite Room</option>
                                <option value="family">Family Room</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="checkIn">Tanggal Check-in</label>
                            <input type="date" id="checkIn" name="checkIn" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="checkOut">Tanggal Check-out</label>
                            <input type="date" id="checkOut" name="checkOut" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="jumlahTamu">Jumlah Tamu</label>
                            <select id="jumlahTamu" name="jumlahTamu" required>
                                <option value="">Pilih Jumlah Tamu</option>
                                <option value="1">1 Orang</option>
                                <option value="2">2 Orang</option>
                                <option value="3">3 Orang</option>
                                <option value="4">4 Orang</option>
                                <option value="5">5+ Orang</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="totalBiaya">Total Biaya</label>
                            <input type="text" id="totalBiaya" name="totalBiaya" readonly placeholder="Akan dihitung otomatis">
                        </div>
                        
                        <div class="form-group full-width">
                            <label for="permintaanKhusus">Permintaan Khusus</label>
                            <textarea id="permintaanKhusus" name="permintaanKhusus" placeholder="Tuliskan permintaan khusus Anda..."></textarea>
                        </div>
                    </div>
                    
                    <button type="submit" class="submit-btn">Konfirmasi Pemesanan</button>
                </form>
            </section>
        </div>
    </main>

    <script>
        // Set minimum date to today
        const today = new Date().toISOString().split('T')[0];
        document.getElementById('checkIn').setAttribute('min', today);
        document.getElementById('checkOut').setAttribute('min', today);

        // Room prices
        const roomPrices = {
            'standard': 350000,
            'deluxe': 500000,
            'suite': 750000,
            'family': 600000
        };

        // Calculate total cost
        function calculateTotal() {
            const roomType = document.getElementById('tipeKamar').value;
            const checkIn = new Date(document.getElementById('checkIn').value);
            const checkOut = new Date(document.getElementById('checkOut').value);
            const totalBiayaField = document.getElementById('totalBiaya');
            
            if (roomType && checkIn && checkOut && checkIn < checkOut) {
                const nights = Math.ceil((checkOut - checkIn) / (1000 * 60 * 60 * 24));
                const total = roomPrices[roomType] * nights;
                totalBiayaField.value = `Rp ${total.toLocaleString('id-ID')} (${nights} malam)`;
            } else {
                totalBiayaField.value = '';
            }
        }

        // Set checkout minimum date when checkin changes
        document.getElementById('checkIn').addEventListener('change', function() {
            const checkInDate = new Date(this.value);
            checkInDate.setDate(checkInDate.getDate() + 1);
            const minCheckOut = checkInDate.toISOString().split('T')[0];
            document.getElementById('checkOut').setAttribute('min', minCheckOut);
            calculateTotal();
        });

        // Calculate total when room type or dates change
        document.getElementById('tipeKamar').addEventListener('change', calculateTotal);
        document.getElementById('checkOut').addEventListener('change', calculateTotal);

        // Form submission
        document.getElementById('bookingForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const bookingData = Object.fromEntries(formData);
            
            // Simple validation
            if (!bookingData.namaLengkap || !bookingData.email || !bookingData.noTelepon || 
                !bookingData.tipeKamar || !bookingData.checkIn || !bookingData.checkOut || 
                !bookingData.jumlahTamu) {
                alert('Mohon lengkapi semua field yang wajib diisi!');
                return;
            }
            
            // Check if checkout is after checkin
            if (new Date(bookingData.checkIn) >= new Date(bookingData.checkOut)) {
                alert('Tanggal check-out harus setelah tanggal check-in!');
                return;
            }
            
            alert('Pemesanan berhasil! Kami akan menghubungi Anda dalam 24 jam untuk konfirmasi.');
            console.log('Booking Data:', bookingData);
        });
    </script>
</body>
</html>