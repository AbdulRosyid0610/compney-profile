<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tentang Kami - Grand Paradise Hotel</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #f39c12;
            --accent-color: #e74c3c;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .navbar {
            background: rgba(255,255,255,0.95) !important;
            backdrop-filter: blur(10px);
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .navbar-brand {
            font-weight: bold;
            font-size: 1.5rem;
        }

        .page-header {
            background: linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), 
                        url('https://i.pinimg.com/736x/c5/87/95/c5879501dae6ecc7304a7daf9e03c058.jpg');
            background-size: cover;
            background-position: center;
            height: 60vh;
            display: flex;
            align-items: center;
            color: white;
            position: relative;
        }

        .section-title {
            color: var(--primary-color);
            font-weight: bold;
            margin-bottom: 3rem;
            position: relative;
        }

        .section-title::after {
            content: '';
            position: absolute;
            bottom: -10px;
            left: 50%;
            transform: translateX(-50%);
            width: 50px;
            height: 3px;
            background: var(--secondary-color);
        }

        .story-card {
            background: white;
            border-radius: 15px;
            padding: 2rem;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
            margin-bottom: 2rem;
        }

        .story-card:hover {
            transform: translateY(-5px);
        }

        .timeline {
            position: relative;
            padding: 2rem 0;
        }

        .timeline::before {
            content: '';
            position: absolute;
            left: 50%;
            top: 0;
            bottom: 0;
            width: 2px;
            background: var(--secondary-color);
            transform: translateX(-50%);
        }

        .timeline-item {
            position: relative;
            margin-bottom: 3rem;
            width: 100%;
        }

        .timeline-item:nth-child(odd) .timeline-content {
            margin-left: 0;
            margin-right: 55%;
            text-align: right;
        }

        .timeline-item:nth-child(even) .timeline-content {
            margin-left: 55%;
            margin-right: 0;
        }

        .timeline-content {
            background: white;
            padding: 2rem;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            position: relative;
        }

        .timeline-date {
            position: absolute;
            left: 50%;
            transform: translateX(-50%);
            background: var(--secondary-color);
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 25px;
            font-weight: bold;
            white-space: nowrap;
        }

        .team-card {
            text-align: center;
            padding: 2rem;
            background: white;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
            margin-bottom: 2rem;
        }

        .team-card:hover {
            transform: translateY(-10px);
        }

        .team-photo {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            background: linear-gradient(45deg, var(--primary-color), var(--secondary-color));
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1rem;
            color: white;
            font-size: 3rem;
        }

        .value-card {
            text-align: center;
            padding: 2rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 15px;
            height: 100%;
            transition: transform 0.3s ease;
        }

        .value-card:hover {
            transform: scale(1.05);
        }

        .value-icon {
            width: 80px;
            height: 80px;
            background: rgba(255,255,255,0.2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1rem;
            font-size: 2rem;
        }

        .stats-section {
            background: var(--primary-color);
            color: white;
            padding: 4rem 0;
        }

        .stat-item {
            text-align: center;
            margin-bottom: 2rem;
        }

        .stat-number {
            font-size: 3rem;
            font-weight: bold;
            color: var(--secondary-color);
            display: block;
        }

        .awards-section {
            background: #f8f9fa;
            padding: 4rem 0;
        }

        .award-item {
            text-align: center;
            padding: 2rem;
            background: white;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            margin-bottom: 2rem;
            transition: transform 0.3s ease;
        }

        .award-item:hover {
            transform: translateY(-5px);
        }

        .award-icon {
            width: 80px;
            height: 80px;
            background: var(--secondary-color);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1rem;
            color: white;
            font-size: 2rem;
        }

        .footer {
            background: var(--primary-color);
            color: white;
            padding: 3rem 0;
        }

        @media (max-width: 768px) {
            .timeline::before {
                left: 30px;
            }
            
            .timeline-item:nth-child(odd) .timeline-content,
            .timeline-item:nth-child(even) .timeline-content {
                margin-left: 80px;
                margin-right: 0;
                text-align: left;
            }
            
            .timeline-date {
                left: 30px;
                transform: translateX(-50%);
            }
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light fixed-top">
        <div class="container">
            <a class="navbar-brand text-primary" href="index.html">
                <i class="fas fa-hotel me-2"></i>Grand Paradise Hotel
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="/">Beranda</a></li>
                    <li class="nav-item"><a class="nav-link" href="{{ route('kamar') }}">Kamar</a></li>
                    <li class="nav-item"><a class="nav-link" href="{{ route('pemesanan') }}">Pemesanan</a></li>
                    <li class="nav-item"><a class="nav-link" href="{{ route('Kontak') }}">Kontak</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Page Header -->
    <section class="page-header">
        <div class="container text-center">
            <h1 class="display-4 mb-4">Tentang Grand Paradise Hotel</h1>
            <p class="lead">Mengenal lebih dekat perjalanan dan dedikasi kami dalam memberikan pelayanan terbaik</p>
        </div>
    </section>

    <!-- Our Story Section -->
    <section class="py-5">
        <div class="container">
            <h2 class="text-center section-title">Cerita Kami</h2>
            <div class="row">
                <div class="col-lg-6 mb-4">
                    <div class="story-card">
                        <h4 class="mb-3"><i class="fas fa-star text-warning me-2"></i>Visi Kami</h4>
                        <p>Menjadi hotel terdepan di Indonesia yang memberikan pengalaman menginap tak terlupakan dengan standar pelayanan internasional, fasilitas modern, dan kehangatan keramahan Indonesia.</p>
                        <p>Kami berkomitmen untuk terus berinovasi dan memberikan nilai lebih bagi setiap tamu yang menginap di hotel kami.</p>
                    </div>
                </div>
                <div class="col-lg-6 mb-4">
                    <div class="story-card">
                        <h4 class="mb-3"><i class="fas fa-heart text-danger me-2"></i>Misi Kami</h4>
                        <p>Memberikan pelayanan prima dengan mengutamakan kepuasan tamu melalui fasilitas berkualitas tinggi, staff profesional, dan inovasi berkelanjutan dalam industri perhotelan.</p>
                        <p>Menciptakan lingkungan kerja yang positif bagi seluruh karyawan dan berkontribusi pada pembangunan pariwisata Indonesia.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Timeline Section -->
    <section class="py-5 bg-light">
        <div class="container">
            <h2 class="text-center section-title">Perjalanan Kami</h2>
            <div class="timeline">
                <div class="timeline-item">
                    <div class="timeline-date">2010</div>
                    <div class="timeline-content">
                        <h5>Berdirinya Grand Paradise Hotel</h5>
                        <p>Memulai perjalanan dengan visi menjadi hotel terbaik di Jakarta. Pembangunan hotel dimulai dengan desain modern dan fasilitas terdepan.</p>
                    </div>
                </div>
                
                <div class="timeline-item">
                    <div class="timeline-date">2012</div>
                    <div class="timeline-content">
                        <h5>Grand Opening</h5>
                        <p>Resmi dibuka untuk umum dengan 150 kamar mewah dan fasilitas lengkap. Menerima tamu pertama dengan antusiasme tinggi.</p>
                    </div>
                </div>
                
                <div class="timeline-item">
                    <div class="timeline-date">2015</div>
                    <div class="timeline-content">
                        <h5>Penghargaan Pertama</h5>
                        <p>Meraih penghargaan "Best New Hotel" dari Indonesia Hotel Awards. Pencapaian yang membanggakan dalam 3 tahun operasional.</p>
                    </div>
                </div>
                
                <div class="timeline-item">
                    <div class="timeline-date">2018</div>
                    <div class="timeline-content">
                        <h5>Renovasi Besar</h5>
                        <p>Melakukan renovasi menyeluruh untuk meningkatkan kualitas fasilitas dan menghadirkan teknologi terbaru di setiap kamar.</p>
                    </div>
                </div>
                
                <div class="timeline-item">
                    <div class="timeline-date">2020</div>
                    <div class="timeline-content">
                        <h5>Sertifikasi Internasional</h5>
                        <p>Memperoleh sertifikasi ISO dan berbagai standar internasional untuk kualitas pelayanan dan keamanan.</p>
                    </div>
                </div>
                
                <div class="timeline-item">
                    <div class="timeline-date">2023</div>
                    <div class="timeline-content">
                        <h5>Ekspansi Digital</h5>
                        <p>Meluncurkan platform digital untuk memberikan pengalaman pemesanan yang lebih mudah dan layanan terdepan bagi tamu.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Our Values Section -->
    <section class="py-5">
        <div class="container">
            <h2 class="text-center section-title">Nilai-Nilai Kami</h2>
            <div class="row">
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="value-card">
                        <div class="value-icon">
                            <i class="fas fa-star"></i>
                        </div>
                        <h5>Excellence</h5>
                        <p>Selalu memberikan yang terbaik dalam setiap aspek pelayanan dengan standar kualitas tertinggi.</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="value-card">
                        <div class="value-icon">
                            <i class="fas fa-handshake"></i>
                        </div>
                        <h5>Integrity</h5>
                        <p>Menjunjung tinggi kejujuran, transparansi, dan etika dalam setiap interaksi bisnis.</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="value-card">
                        <div class="value-icon">
                            <i class="fas fa-users"></i>
                        </div>
                        <h5>Teamwork</h5>
                        <p>Membangun kerja sama yang solid untuk mencapai tujuan bersama dan kepuasan tamu.</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="value-card">
                        <div class="value-icon">
                            <i class="fas fa-lightbulb"></i>
                        </div>
                        <h5>Innovation</h5>
                        <p>Terus berinovasi untuk memberikan pengalaman baru dan solusi terdepan bagi tamu.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Management Team Section -->
    <section class="py-5 bg-light">
        <div class="container">
            <h2 class="text-center section-title">Tim Manajemen</h2>
            <div class="row">
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="team-card">
                        <div class="team-photo">
                            <i class="fas fa-user-tie"></i>
                        </div>
                        <h5>Budi Santoso</h5>
                        <p class="text-muted">General Manager</p>
                        <p>Berpengalaman 15 tahun di industri perhotelan internasional dengan fokus pada excellent service dan operational excellence.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="team-card">
                        <div class="team-photo">
                            <i class="fas fa-user-graduate"></i>
                        </div>
                        <h5>Sarah Wijaya</h5>
                        <p class="text-muted">Operations Director</p>
                        <p>Ahli dalam manajemen operasional hotel dengan track record memimpin tim besar dan meningkatkan efisiensi operasional.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="team-card">
                        <div class="team-photo">
                            <i class="fas fa-user-friends"></i>
                        </div>
                        <h5>Ahmad Rahman</h5>
                        <p class="text-muted">Guest Relations Manager</p>
                        <p>Spesialis dalam customer service dan guest experience dengan kemampuan mengelola kepuasan tamu di level tertinggi.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Statistics Section -->
    <section class="stats-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="stat-item">
                        <span class="stat-number" data-target="13">0</span>
                        <h5>Tahun Pengalaman</h5>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="stat-item">
                        <span class="stat-number" data-target="50000">0</span>
                        <h5>Tamu Dilayani</h5>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="stat-item">
                        <span class="stat-number" data-target="98">0</span>
                        <h5>% Kepuasan Tamu</h5>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="stat-item">
                        <span class="stat-number" data-target="150">0</span>
                        <h5>Karyawan Profesional</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Awards Section -->
    <section class="awards-section">
        <div class="container">
            <h2 class="text-center section-title">Penghargaan & Sertifikasi</h2>
            <div class="row">
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="award-item">
                        <div class="award-icon">
                            <i class="fas fa-trophy"></i>
                        </div>
                        <h5>Best Hotel 2023</h5>
                        <p>Indonesia Tourism Awards</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="award-item">
                        <div class="award-icon">
                            <i class="fas fa-certificate"></i>
                        </div>
                        <h5>ISO 9001:2015</h5>
                        <p>Quality Management System</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="award-item">
                        <div class="award-icon">
                            <i class="fas fa-leaf"></i>
                        </div>
                        <h5>Green Hotel</h5>
                        <p>Environmental Certification</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="award-item">
                        <div class="award-icon">
                            <i class="fas fa-shield-alt"></i>
                        </div>
                        <h5>Safety First</h5>
                        <p>Health & Safety Standards</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 mb-4">
                    <h5><i class="fas fa-hotel me-2"></i>Agria Hotel</h5>
                    <p>Hotel mewah dengan pelayanan terbaik di jantung kota Jakarta. Nikmati pengalaman menginap yang tak terlupakan bersama kami.</p>
                </div>
                <div class="col-lg-4 mb-4">
                    <h5>Kontak Kami</h5>
                    <p><i class="fas fa-map-marker-alt me-2"></i>Jl. Sudirman No. 123, Jakarta Pusat</p>
                    <p><i class="fas fa-phone me-2"></i>+62 21 1234 5678</p>
                    <p><i class="fas fa-envelope me-2"></i>info@grandparadisehotel.com</p>
                </div>
                <div class="col-lg-4 mb-4">
                    <h5>Ikuti Kami</h5>
                    <div class="d-flex gap-3">
                        <a href="#" class="text-white"><i class="fab fa-facebook fa-2x"></i></a>
                        <a href="#" class="text-white"><i class="fab fa-instagram fa-2x"></i></a>
                        <a href="#" class="text-white"><i class="fab fa-twitter fa-2x"></i></a>
                        <a href="#" class="text-white"><i class="fab fa-linkedin fa-2x"></i></a>
                    </div>
                </div>
            </div>
            <hr class="my-4">
            <div class="text-center">
                <p>&copy; 2025 Grand Paradise Hotel. All rights reserved. | Built with Laravel & Bootstrap</p>
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <script>
        // Counter Animation
        function animateCounters() {
            const counters = document.querySelectorAll('.stat-number');
            
            counters.forEach(counter => {
                const target = parseInt(counter.getAttribute('data-target'));
                const duration = 2000; // 2 seconds
                const increment = target / (duration / 16); // 60fps
                let current = 0;
                
                const updateCounter = () => {
                    if (current < target) {
                        current += increment;
                        counter.textContent = Math.floor(current).toLocaleString();
                        requestAnimationFrame(updateCounter);
                    } else {
                        counter.textContent = target.toLocaleString();
                    }
                };
                
                updateCounter();
            });
        }

        // Intersection Observer for animations
        const observerOptions = {
            threshold: 0.5,
            rootMargin: '0px 0px -100px 0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    if (entry.target.classList.contains('stats-section')) {
                        animateCounters();
                    }
                    
                    // Add animation classes
                    const cards = entry.target.querySelectorAll('.story-card, .team-card, .award-item, .value-card');
                    cards.forEach((card, index) => {
                        setTimeout(() => {
                            card.style.opacity = '0';
                            card.style.transform = 'translateY(30px)';
                            card.style.transition = 'all 0.6s ease';
                            
                            setTimeout(() => {
                                card.style.opacity = '1';
                                card.style.transform = 'translateY(0)';
                            }, 100);
                        }, index * 100);
                    });
                    
                    observer.unobserve(entry.target);
                }
            });
        }, observerOptions);

        // Observe sections
        document.addEventListener('DOMContentLoaded', function() {
            const sections = document.querySelectorAll('section');
            sections.forEach(section => {
                observer.observe(section);
            });
        });

        // Timeline animation
        const timelineObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateX(0)';
                }
            });
        }, { threshold: 0.5 });

        document.querySelectorAll('.timeline-item').forEach((item, index) => {
            item.style.opacity = '0';
            item.style.transform = index % 2 === 0 ? 'translateX(-50px)' : 'translateX(50px)';
            item.style.transition = 'all 0.6s ease';
            timelineObserver.observe(item);
        });

        // Smooth scrolling for navigation
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });
    </script>
</body>
</html>