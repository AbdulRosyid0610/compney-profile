<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kontak - Hotel Agria Bogor</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
            color: #333;
            line-height: 1.6;
        }

        .header {
            background-color: white;
            padding: 15px 0;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        .nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            display: flex;
            align-items: center;
            color: #007bff;
            font-size: 20px;
            font-weight: bold;
        }

        .logo::before {
            content: "🏨";
            margin-right: 10px;
        }

        .nav-menu {
            display: flex;
            list-style: none;
            gap: 30px;
        }

        .nav-menu a {
            text-decoration: none;
            color: #666;
            font-weight: 500;
            transition: color 0.3s;
        }

        .nav-menu a:hover,
        .nav-menu a.active {
            color: #007bff;
        }

        .hero-section {
            background: linear-gradient(135deg, #007bff 0%, #0056b3 100%);
            color: white;
            padding: 80px 0 60px;
            text-align: center;
        }

        .hero-title {
            font-size: 2.5rem;
            margin-bottom: 20px;
            font-weight: 700;
        }

        .hero-subtitle {
            font-size: 1.2rem;
            opacity: 0.9;
            max-width: 600px;
            margin: 0 auto;
        }

        .contact-section {
            padding: 60px 0;
        }

        .contact-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 40px;
            margin-bottom: 60px;
        }

        .contact-info {
            background: white;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }

        .contact-form {
            background: white;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }

        .section-title {
            font-size: 1.8rem;
            margin-bottom: 30px;
            color: #333;
            position: relative;
            padding-bottom: 15px;
        }

        .section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 50px;
            height: 3px;
            background-color: #ffc107;
        }

        .contact-item {
            display: flex;
            align-items: flex-start;
            margin-bottom: 25px;
            padding: 20px;
            background: #f8f9fa;
            border-radius: 10px;
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .contact-item:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        .contact-icon {
            font-size: 1.5rem;
            margin-right: 15px;
            color: #007bff;
            min-width: 40px;
        }

        .contact-details h3 {
            font-size: 1.1rem;
            margin-bottom: 5px;
            color: #333;
        }

        .contact-details p {
            color: #666;
            margin: 0;
        }

        .contact-details a {
            color: #007bff;
            text-decoration: none;
            transition: color 0.3s;
        }

        .contact-details a:hover {
            color: #0056b3;
            text-decoration: underline;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #555;
        }

        input[type="text"],
        input[type="email"],
        input[type="tel"],
        select,
        textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s;
            background-color: white;
        }

        input[type="text"]:focus,
        input[type="email"]:focus,
        input[type="tel"]:focus,
        select:focus,
        textarea:focus {
            outline: none;
            border-color: #007bff;
            box-shadow: 0 0 0 3px rgba(0,123,255,0.1);
        }

        textarea {
            resize: vertical;
            min-height: 120px;
        }

        .submit-btn {
            background: linear-gradient(135deg, #ffc107 0%, #e0a800 100%);
            color: #333;
            border: none;
            padding: 15px 30px;
            border-radius: 8px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s;
            width: 100%;
        }

        .submit-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(255,193,7,0.3);
        }

        .map-section {
            background: white;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            text-align: center;
        }

        .map-placeholder {
            background: linear-gradient(135deg, #e9ecef 0%, #dee2e6 100%);
            height: 400px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-top: 20px;
            border: 2px dashed #adb5bd;
        }

        .map-placeholder p {
            color: #6c757d;
            font-size: 1.1rem;
        }

        .social-links {
            margin-top: 30px;
            text-align: center;
        }

        .social-links h3 {
            margin-bottom: 20px;
            color: #333;
        }

        .social-icons {
            display: flex;
            justify-content: center;
            gap: 15px;
        }

        .social-icon {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 50px;
            height: 50px;
            background: #007bff;
            color: white;
            border-radius: 50%;
            text-decoration: none;
            font-size: 1.2rem;
            transition: all 0.3s;
        }

        .social-icon:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0,123,255,0.4);
        }

        .working-hours {
            background: #f8f9fa;
            padding: 25px;
            border-radius: 10px;
            margin-top: 20px;
        }

        .working-hours h4 {
            margin-bottom: 15px;
            color: #333;
            text-align: center;
        }

        .hours-list {
            list-style: none;
        }

        .hours-list li {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px solid #dee2e6;
        }

        .hours-list li:last-child {
            border-bottom: none;
        }

        @media (max-width: 768px) {
            .nav-menu {
                display: none;
            }
            
            .hero-title {
                font-size: 2rem;
            }
            
            .contact-grid {
                grid-template-columns: 1fr;
                gap: 30px;
            }
            
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .contact-info,
            .contact-form,
            .map-section {
                padding: 30px 20px;
            }
            
            .social-icons {
                flex-wrap: wrap;
            }
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="container">
            <nav class="nav">
                <div class="logo">Hotel Agria Bogor</div>
                <ul class="nav-menu">
                    <li><a href="/">Tentang Agria Bogor</a></li>
                    <li><a href="/kamar">Kamar</a></li>
                    <li><a href="/Fasilitas">Fasilitas</a></li>
                    <li><a href="/pemesanan">Pemesanan</a></li>
                    <li><a href="/Kontak" class="active">Kontak</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section class="hero-section">
        <div class="container">
            <h1 class="hero-title">Hubungi Kami</h1>
            <p class="hero-subtitle">Kami siap membantu Anda 24/7. Jangan ragu untuk menghubungi tim profesional kami untuk informasi dan bantuan apapun yang Anda butuhkan.</p>
        </div>
    </section>

    <main class="contact-section">
        <div class="container">
            <div class="contact-grid">
                <div class="contact-info">
                    <h2 class="section-title">Informasi Kontak</h2>
                    
                    <div class="contact-item">
                        <div class="contact-icon">📍</div>
                        <div class="contact-details">
                            <h3>Alamat</h3>
                            <p>Jl. Pajajaran No. 35, Bantarjati<br>
                            Bogor Utara, Kota Bogor<br>
                            Jawa Barat 16153</p>
                        </div>
                    </div>

                    <div class="contact-item">
                        <div class="contact-icon">📞</div>
                        <div class="contact-details">
                            <h3>Telepon</h3>
                            <p><a href="tel:+622518312345">(0251) 831-2345</a><br>
                            <a href="tel:+6281234567890">+62 812-3456-7890</a></p>
                        </div>
                    </div>

                    <div class="contact-item">
                        <div class="contact-icon">✉️</div>
                        <div class="contact-details">
                            <h3>Email</h3>
                            <p><a href="mailto:info@hotelagriabogor.com">info@hotelagriabogor.com</a><br>
                            <a href="mailto:reservasi@hotelagriabogor.com">reservasi@hotelagriabogor.com</a></p>
                        </div>
                    </div>

                    <div class="contact-item">
                        <div class="contact-icon">🌐</div>
                        <div class="contact-details">
                            <h3>Website</h3>
                            <p><a href="https://www.hotelagriabogor.com" target="_blank">www.hotelagriabogor.com</a></p>
                        </div>
                    </div>

                    <div class="working-hours">
                        <h4>Jam Operasional</h4>
                        <ul class="hours-list">
                            <li><span>Senin - Kamis</span> <span>24 Jam</span></li>
                            <li><span>Jumat - Minggu</span> <span>24 Jam</span></li>
                            <li><span>Front Desk</span> <span>24 Jam</span></li>
                            <li><span>Restaurant</span> <span>06:00 - 22:00</span></li>
                            <li><span>Room Service</span> <span>24 Jam</span></li>
                        </ul>
                    </div>

                    <div class="social-links">
                        <h3>Ikuti Kami</h3>
                        <div class="social-icons">
                            <a href="#" class="social-icon" title="Facebook">📘</a>
                            <a href="#" class="social-icon" title="Instagram">📷</a>
                            <a href="#" class="social-icon" title="Twitter">🐦</a>
                            <a href="#" class="social-icon" title="WhatsApp">💬</a>
                            <a href="#" class="social-icon" title="YouTube">📺</a>
                        </div>
                    </div>
                </div>

                <div class="contact-form">
                    <h2 class="section-title">Kirim Pesan</h2>
                    
                    <form id="contactForm">
                        <div class="form-row">
                            <div class="form-group">
                                <label for="firstName">Nama Depan</label>
                                <input type="text" id="firstName" name="firstName" required>
                            </div>
                            <div class="form-group">
                                <label for="lastName">Nama Belakang</label>
                                <input type="text" id="lastName" name="lastName" required>
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="email" id="email" name="email" required>
                            </div>
                            <div class="form-group">
                                <label for="phone">No. Telepon</label>
                                <input type="tel" id="phone" name="phone">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="subject">Subjek</label>
                            <select id="subject" name="subject" required>
                                <option value="">Pilih Subjek</option>
                                <option value="reservasi">Pertanyaan Reservasi</option>
                                <option value="fasilitas">Informasi Fasilitas</option>
                                <option value="keluhan">Keluhan/Saran</option>
                                <option value="event">Event & Meeting</option>
                                <option value="lainnya">Lainnya</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="message">Pesan</label>
                            <textarea id="message" name="message" placeholder="Tuliskan pesan Anda di sini..." required></textarea>
                        </div>

                        <button type="submit" class="submit-btn">📨 Kirim Pesan</button>
                    </form>
                </div>
            </div>

            <div class="map-section">
                <h2 class="section-title">Lokasi Kami</h2>
                <p>Hotel Agria Bogor terletak strategis di pusat Kota Bogor, mudah diakses dari berbagai lokasi wisata dan pusat bisnis.</p>
                <div class="map-placeholder">
                    <p>🗺️ Peta Lokasi Hotel Agria Bogor<br>
                    <small>Klik untuk membuka di Google Maps</small></p>
                </div>
            </div>
        </div>
    </main>

    <script>
        // Form submission handler
        document.getElementById('contactForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const contactData = Object.fromEntries(formData);
            
            // Basic validation
            if (!contactData.firstName || !contactData.lastName || !contactData.email || !contactData.subject || !contactData.message) {
                alert('Mohon lengkapi semua field yang wajib diisi!');
                return;
            }
            
            // Email validation
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(contactData.email)) {
                alert('Format email tidak valid!');
                return;
            }
            
            // Show success message
            alert('Pesan Anda telah terkirim! Kami akan merespon dalam 2-4 jam kerja.');
            
            // Log the data (in real implementation, send to server)
            console.log('Contact Data:', contactData);
            
            // Reset form
            this.reset();
        });

        // Map placeholder click handler
        document.querySelector('.map-placeholder').addEventListener('click', function() {
            const googleMapsUrl = 'https://www.google.com/maps/search/Hotel+Bogor+Jl.+Pajajaran+No.+35+Bantarjati';
            window.open(googleMapsUrl, '_blank');
        });

        // Social media click handlers
        document.querySelectorAll('.social-icon').forEach(icon => {
            icon.addEventListener('click', function(e) {
                e.preventDefault();
                const platform = this.getAttribute('title');
                alert(`Mengalihkan ke ${platform}...`);
                // In real implementation, redirect to actual social media pages
            });
        });

        // Phone number click to call
        document.querySelectorAll('a[href^="tel:"]').forEach(link => {
            link.addEventListener('click', function(e) {
                if (!('ontouchstart' in window)) {
                    e.preventDefault();
                    alert('Nomor telepon: ' + this.textContent);
                }
            });
        });

        // Auto-resize textarea
        document.getElementById('message').addEventListener('input', function() {
            this.style.height = 'auto';
            this.style.height = this.scrollHeight + 'px';
        });
    </script>
</body>
</html>