<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fasilitas - Hotel Agria Bogor</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        /* Header */
        header {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 0;
        }

        .logo {
            font-size: 1.5rem;
            font-weight: bold;
            color: #4a90e2;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .logo::before {
            content: "🏨";
            font-size: 1.8rem;
        }

        .nav-links {
            display: flex;
            list-style: none;
            gap: 2rem;
        }

        .nav-links a {
            text-decoration: none;
            color: #333;
            font-weight: 500;
            transition: all 0.3s ease;
            position: relative;
            padding: 5px 0;
        }

        .nav-links a:hover {
            color: #4a90e2;
            transform: translateY(-2px);
        }

        .nav-links a.active {
            color: #4a90e2;
        }

        .nav-links a::after {
            content: '';
            position: absolute;
            width: 0;
            height: 2px;
            bottom: 0;
            left: 0;
            background: #4a90e2;
            transition: width 0.3s ease;
        }

        .nav-links a:hover::after,
        .nav-links a.active::after {
            width: 100%;
        }

        /* Hero Section */
        .hero {
            background: linear-gradient(rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.4)),
                        url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 600"><rect fill="%23667eea" width="1200" height="600"/><circle cx="200" cy="150" r="100" fill="%23764ba2" opacity="0.3"/><circle cx="800" cy="400" r="150" fill="%2356ab2f" opacity="0.2"/><circle cx="1000" cy="100" r="80" fill="%23ff6b6b" opacity="0.3"/></svg>');
            background-size: cover;
            background-position: center;
            color: white;
            text-align: center;
            padding: 6rem 0;
            margin-bottom: 4rem;
        }

        .hero h1 {
            font-size: 3rem;
            margin-bottom: 1rem;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
        }

        .hero p {
            font-size: 1.2rem;
            max-width: 600px;
            margin: 0 auto;
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.3);
        }

        /* Facilities Section */
        .facilities-section {
            padding: 4rem 0;
        }

        .section-title {
            text-align: center;
            font-size: 2.5rem;
            color: white;
            margin-bottom: 3rem;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
        }

        .facilities-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
            margin-bottom: 4rem;
        }

        .facility-card {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            transition: all 0.3s ease;
            backdrop-filter: blur(10px);
        }

        .facility-card:hover {
            transform: translateY(-15px);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
        }

        .facility-image {
            height: 200px;
            background: linear-gradient(45deg, #667eea, #764ba2);
            position: relative;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .facility-icon {
            font-size: 4rem;
            color: white;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
            z-index: 2;
        }

        .facility-image::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 200"><defs><pattern id="pattern" x="0" y="0" width="40" height="40" patternUnits="userSpaceOnUse"><circle cx="20" cy="20" r="2" fill="white" opacity="0.1"/></pattern></defs><rect width="400" height="200" fill="url(%23pattern)"/></svg>');
            z-index: 1;
        }

        .facility-content {
            padding: 2rem;
        }

        .facility-title {
            font-size: 1.5rem;
            font-weight: bold;
            color: #333;
            margin-bottom: 1rem;
        }

        .facility-description {
            color: #666;
            margin-bottom: 1.5rem;
            line-height: 1.6;
        }

        .facility-features {
            display: flex;
            flex-wrap: wrap;
            gap: 0.5rem;
            margin-bottom: 1.5rem;
        }

        .feature-tag {
            background: #e3f2fd;
            color: #1976d2;
            padding: 5px 12px;
            border-radius: 15px;
            font-size: 0.9rem;
            font-weight: 500;
        }

        .facility-hours {
            background: #f8f9fa;
            padding: 1rem;
            border-radius: 10px;
            border-left: 4px solid #4a90e2;
        }

        .hours-title {
            font-weight: bold;
            color: #4a90e2;
            margin-bottom: 0.5rem;
        }

        .hours-text {
            color: #666;
            font-size: 0.9rem;
        }

        /* Special Facilities */
        .special-facilities {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 3rem;
            margin: 4rem 0;
        }

        .special-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 2rem;
        }

        .special-item {
            text-align: center;
            color: white;
            padding: 2rem;
            border-radius: 15px;
            background: rgba(255, 255, 255, 0.1);
            transition: all 0.3s ease;
            border: 2px solid transparent;
        }

        .special-item:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: translateY(-10px);
            border-color: rgba(255, 255, 255, 0.3);
        }

        .special-icon {
            font-size: 3rem;
            margin-bottom: 1rem;
            display: block;
        }

        .special-title {
            font-size: 1.3rem;
            font-weight: bold;
            margin-bottom: 1rem;
        }

        .special-description {
            opacity: 0.9;
            line-height: 1.6;
        }

        /* Services Section */
        .services-section {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            padding: 3rem;
            margin: 4rem 0;
            backdrop-filter: blur(10px);
        }

        .services-title {
            text-align: center;
            color: #333;
            font-size: 2rem;
            margin-bottom: 2rem;
        }

        .services-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 1.5rem;
        }

        .service-item {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1.5rem;
            background: #f8f9fa;
            border-radius: 15px;
            transition: all 0.3s ease;
            border-left: 4px solid #4a90e2;
        }

        .service-item:hover {
            transform: translateX(10px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .service-icon {
            font-size: 2rem;
            color: #4a90e2;
            min-width: 60px;
            text-align: center;
        }

        .service-text {
            flex: 1;
        }

        .service-text h4 {
            color: #333;
            font-weight: bold;
            margin-bottom: 0.5rem;
        }

        .service-text p {
            color: #666;
            font-size: 0.9rem;
        }

        /* Animation */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes float {
            0%, 100% {
                transform: translateY(0px);
            }
            50% {
                transform: translateY(-10px);
            }
        }

        .facility-card {
            animation: fadeInUp 0.6s ease forwards;
        }

        .facility-card:nth-child(2) {
            animation-delay: 0.1s;
        }

        .facility-card:nth-child(3) {
            animation-delay: 0.2s;
        }

        .facility-card:nth-child(4) {
            animation-delay: 0.3s;
        }

        .facility-card:nth-child(5) {
            animation-delay: 0.4s;
        }

        .facility-card:nth-child(6) {
            animation-delay: 0.5s;
        }

        .facility-icon {
            animation: float 3s ease-in-out infinite;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .nav-links {
                flex-direction: column;
                gap: 1rem;
            }

            .hero h1 {
                font-size: 2rem;
            }

            .hero p {
                font-size: 1rem;
            }

            .section-title {
                font-size: 2rem;
            }

            .facilities-grid {
                grid-template-columns: 1fr;
            }

            .special-facilities,
            .services-section {
                padding: 2rem;
            }

            .facility-content {
                padding: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <header>
        <nav class="container">
            <div class="logo">Hotel Agria Bogor</div>
            <ul class="nav-links">
                <li><a href="/">Beranda</a></li>
                <li><a href="/kamar">Kamar</a></li>
                <li><a href="/Fasilitas" class="active">Fasilitas</a></li>
                <li><a href="/pemesanan">Pemesanan</a></li>
                <li><a href="/Kontak">Kontak</a></li>
            </ul>
        </nav>
    </header>

    <section class="hero">
        <div class="container">
            <h1>Fasilitas Hotel</h1>
            <p>Nikmati berbagai fasilitas terbaik yang kami sediakan untuk kenyamanan dan kepuasan Anda selama menginap</p>
        </div>
    </section>

    <section class="facilities-section">
        <div class="container">
            <h2 class="section-title">Fasilitas Utama</h2>
            
            <div class="facilities-grid">
                <!-- Swimming Pool -->
                <div class="facility-card">
                    <div class="facility-image">
                        <div class="facility-icon">🏊‍♂️</div>
                    </div>
                    <div class="facility-content">
                        <h3 class="facility-title">Kolam Renang</h3>
                        <p class="facility-description">Kolam renang outdoor dengan pemandangan indah dan area berjemur yang nyaman. Dilengkapi dengan kolam anak-anak untuk keamanan si kecil.</p>
                        <div class="facility-features">
                            <span class="feature-tag">🌊 Kolam Dewasa</span>
                            <span class="feature-tag">👶 Kolam Anak</span>
                            <span class="feature-tag">🏖️ Sun Deck</span>
                            <span class="feature-tag">🚿 Shower</span>
                        </div>
                        <div class="facility-hours">
                            <div class="hours-title">Jam Operasional:</div>
                            <div class="hours-text">06:00 - 22:00 WIB</div>
                        </div>
                    </div>
                </div>

                <!-- Restaurant -->
                <div class="facility-card">
                    <div class="facility-image">
                        <div class="facility-icon">🍽️</div>
                    </div>
                    <div class="facility-content">
                        <h3 class="facility-title">Restaurant & Cafe</h3>
                        <p class="facility-description">Restoran mewah dengan menu Indonesia dan internasional. Chef berpengalaman menyajikan hidangan lezat dengan bahan-bahan segar berkualitas tinggi.</p>
                        <div class="facility-features">
                            <span class="feature-tag">🍜 Menu Indonesia</span>
                            <span class="feature-tag">🍝 Menu Internasional</span>
                            <span class="feature-tag">☕ Coffee & Tea</span>
                            <span class="feature-tag">🍰 Dessert</span>
                        </div>
                        <div class="facility-hours">
                            <div class="hours-title">Jam Operasional:</div>
                            <div class="hours-text">06:00 - 23:00 WIB</div>
                        </div>
                    </div>
                </div>

                <!-- Fitness Center -->
                <div class="facility-card">
                    <div class="facility-image">
                        <div class="facility-icon">💪</div>
                    </div>
                    <div class="facility-content">
                        <h3 class="facility-title">Fitness Center</h3>
                        <p class="facility-description">Pusat kebugaran lengkap dengan peralatan modern dan trainer profesional. Jaga kebugaran Anda bahkan saat berlibur.</p>
                        <div class="facility-features">
                            <span class="feature-tag">🏋️ Gym Equipment</span>
                            <span class="feature-tag">🧘 Yoga Area</span>
                            <span class="feature-tag">👨‍🏫 Personal Trainer</span>
                            <span class="feature-tag">🏃 Treadmill</span>
                        </div>
                        <div class="facility-hours">
                            <div class="hours-title">Jam Operasional:</div>
                            <div class="hours-text">05:00 - 22:00 WIB</div>
                        </div>
                    </div>
                </div>

                <!-- Spa & Wellness -->
                <div class="facility-card">
                    <div class="facility-image">
                        <div class="facility-icon">🧘‍♀️</div>
                    </div>
                    <div class="facility-content">
                        <h3 class="facility-title">Spa & Wellness</h3>
                        <p class="facility-description">Pusat relaksasi dengan berbagai treatment spa tradisional dan modern. Manjakan diri Anda dengan layanan pijat dan perawatan tubuh.</p>
                        <div class="facility-features">
                            <span class="feature-tag">💆 Massage</span>
                            <span class="feature-tag">🛁 Sauna</span>
                            <span class="feature-tag">💅 Manicure</span>
                            <span class="feature-tag">🌿 Aromatherapy</span>
                        </div>
                        <div class="facility-hours">
                            <div class="hours-title">Jam Operasional:</div>
                            <div class="hours-text">09:00 - 21:00 WIB</div>
                        </div>
                    </div>
                </div>

                <!-- Business Center -->
                <div class="facility-card">
                    <div class="facility-image">
                        <div class="facility-icon">💼</div>
                    </div>
                    <div class="facility-content">
                        <h3 class="facility-title">Business Center</h3>
                        <p class="facility-description">Fasilitas bisnis lengkap dengan ruang meeting, akses internet cepat, dan peralatan presentasi modern untuk kebutuhan bisnis Anda.</p>
                        <div class="facility-features">
                            <span class="feature-tag">🖥️ Computer</span>
                            <span class="feature-tag">🖨️ Printer</span>
                            <span class="feature-tag">📞 Teleconference</span>
                            <span class="feature-tag">📊 Projector</span>
                        </div>
                        <div class="facility-hours">
                            <div class="hours-title">Jam Operasional:</div>
                            <div class="hours-text">24 Jam</div>
                        </div>
                    </div>
                </div>

                <!-- Kids Club -->
                <div class="facility-card">
                    <div class="facility-image">
                        <div class="facility-icon">🎮</div>
                    </div>
                    <div class="facility-content">
                        <h3 class="facility-title">Kids Club</h3>
                        <p class="facility-description">Area bermain anak yang aman dan menyenangkan dengan berbagai permainan edukatif dan pengawasan profesional.</p>
                        <div class="facility-features">
                            <span class="feature-tag">🎪 Play Area</span>
                            <span class="feature-tag">🎨 Arts & Crafts</span>
                            <span class="feature-tag">📚 Reading Corner</span>
                            <span class="feature-tag">👩‍🏫 Supervisor</span>
                        </div>
                        <div class="facility-hours">
                            <div class="hours-title">Jam Operasional:</div>
                            <div class="hours-text">08:00 - 20:00 WIB</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Special Facilities -->
            <div class="special-facilities">
                <h2 class="section-title">Fasilitas Khusus</h2>
                <div class="special-grid">
                    <div class="special-item">
                        <span class="special-icon">🅿️</span>
                        <h3 class="special-title">Parkir Gratis</h3>
                        <p class="special-description">Area parkir luas dan aman untuk mobil dan motor dengan sistem keamanan 24 jam</p>
                    </div>
                    <div class="special-item">
                        <span class="special-icon">📶</span>
                        <h3 class="special-title">WiFi Gratis</h3>
                        <p class="special-description">Koneksi internet berkecepatan tinggi di seluruh area hotel tanpa biaya tambahan</p>
                    </div>
                    <div class="special-item">
                        <span class="special-icon">🛎️</span>
                        <h3 class="special-title">Concierge 24/7</h3>
                        <p class="special-description">Layanan concierge 24 jam untuk membantu kebutuhan dan informasi wisata Anda</p>
                    </div>
                    <div class="special-item">
                        <span class="special-icon">🚗</span>
                        <h3 class="special-title">Airport Transfer</h3>
                        <p class="special-description">Layanan antar jemput bandara dengan kendaraan nyaman dan driver berpengalaman</p>
                    </div>
                </div>
            </div>

            <!-- Services -->
            <div class="services-section">
                <h2 class="services-title">Layanan Tambahan</h2>
                <div class="services-grid">
                    <div class="service-item">
                        <div class="service-icon">🧺</div>
                        <div class="service-text">
                            <h4>Laundry Service</h4>
                            <p>Layanan cuci pakaian dengan standar hotel berbintang</p>
                        </div>
                    </div>
                    <div class="service-item">
                        <div class="service-icon">🍽️</div>
                        <div class="service-text">
                            <h4>Room Service</h4>
                            <p>Pesan makanan dan minuman langsung ke kamar Anda</p>
                        </div>
                    </div>
                    <div class="service-item">
                        <div class="service-icon">🎫</div>
                        <div class="service-text">
                            <h4>Tour & Travel</h4>
                            <p>Bantuan pemesanan tiket dan paket wisata Bogor</p>
                        </div>
                    </div>
                    <div class="service-item">
                        <div class="service-icon">💊</div>
                        <div class="service-text">
                            <h4>Medical Service</h4>
                            <p>Layanan kesehatan dasar dan panggilan dokter</p>
                        </div>
                    </div>
                    <div class="service-item">
                        <div class="service-icon">👔</div>
                        <div class="service-text">
                            <h4>Dry Cleaning</h4>
                            <p>Layanan dry cleaning untuk pakaian formal</p>
                        </div>
                    </div>
                    <div class="service-item">
                        <div class="service-icon">🔐</div>
                        <div class="service-text">
                            <h4>Safe Deposit</h4>
                            <p>Brankas aman untuk menyimpan barang berharga</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script>
        // Add scroll animation for facility cards
        window.addEventListener('scroll', () => {
            const cards = document.querySelectorAll('.facility-card, .special-item, .service-item');
            cards.forEach(card => {
                const cardTop = card.getBoundingClientRect().top;
                const windowHeight = window.innerHeight;
                
                if (cardTop < windowHeight - 100) {
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                }
            });
        });

        // Add interactive hover effects
        document.querySelectorAll('.facility-card').forEach(card => {
            card.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-20px) scale(1.02)';
            });
            
            card.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(0) scale(1)';
            });
        });

        // Add click effects for service items
        document.querySelectorAll('.service-item').forEach(item => {
            item.addEventListener('click', function() {
                // Add ripple effect
                this.style.transform = 'scale(0.98)';
                setTimeout(() => {
                    this.style.transform = 'translateX(10px)';
                }, 150);
            });
        });

        // Initialize page animations
        document.addEventListener('DOMContentLoaded', function() {
            // Fade in hero section
            const hero = document.querySelector('.hero');
            hero.style.opacity = '0';
            hero.style.transform = 'translateY(50px)';
            
            setTimeout(() => {
                hero.style.transition = 'all 1s ease';
                hero.style.opacity = '1';
                hero.style.transform = 'translateY(0)';
            }, 100);

            // Stagger animation for facility cards
            const facilityCards = document.querySelectorAll('.facility-card');
            facilityCards.forEach((card, index) => {
                card.style.opacity = '0';
                card.style.transform = 'translateY(50px)';
                
                setTimeout(() => {
                    card.style.transition = 'all 0.8s ease';
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                }, 200 + (index * 100));
            });
        });
    </script>
</body>
</html>