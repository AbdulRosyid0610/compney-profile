<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hotel Agria Bogor Tajur</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        /* Minimal custom CSS for things Bootstrap doesn't handle */
        .hero-section {
            background:  
                        url('https://dynamic-media-cdn.tripadvisor.com/media/photo-o/15/62/0f/06/agria-hotel-bogor.jpg?w=900&h=500&s=1');
            background-size: cover;
            background-position: center;
            height: 100vh;
            color: white;
        }
        
        .room-image {
            height: 200px;
            background: linear-gradient(45deg, #f8f9fa, #e9ecef);
            display: flex;
            align-items: center;
            justify-content: center;
            color: #6c757d;
        }
        
        .price-tag {
            background: #f39c12;
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 25px;
            font-weight: bold;
        }
        
        .feature-icon {
            width: 60px;
            height: 60px;
            background: #2c3e50;
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            margin: 0 auto 1rem;
        }
        
        .section-title {
            position: relative;
        }
        
        .section-title::after {
            content: '';
            position: absolute;
            bottom: -10px;
            left: 50%;
            transform: translateX(-50%);
            width: 50px;
            height: 3px;
            background: #f39c12;
        }
        
        .alert-booking {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 15px;
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white fixed-top shadow-sm">
        <div class="container">
            <a class="navbar-brand text-primary fw-bold fs-4" href="#home">
                <i class="fas fa-hotel me-2"></i>Hotel Agria Bogor
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="{{ route('Tentang agria') }}">Tentang Agria Bogor</a></li>
                    <li class="nav-item"><a class="nav-link" href="{{ route('kamar') }}">Kamar</a></li>
                    <li class="nav-item"><a class="nav-link" href="{{ route('Fasilitas') }}">Fasilitas</a></li>
                    <li class="nav-item"><a class="nav-link" href="{{ route('pemesanan') }}">Pemesanan</a></li>
                    <li class="nav-item"><a class="nav-link" href="{{ route('Kontak') }}">Kontak</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section id="home" class="hero-section d-flex align-items-center">
        <div class="container text-center">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <h1 class="display-4 fw-bold mb-4">
                        Selamat Datang di Hotel Agria Bogor
                    </h1>
                    <p class="lead mb-4">
                        Nikmati pengalaman menginap yang tak terlupakan dengan layanan terbaik dan fasilitas mewah di kota Bogor
                    </p>
                    <div class="d-flex justify-content-center gap-3">
                        <a href="#booking" class="btn btn-warning btn-lg text-white">
                            <i class="fas fa-calendar-check me-2"></i>Pesan Sekarang
                        </a>
                        <a href="#rooms" class="btn btn-outline-light btn-lg">
                            <i class="fas fa-eye me-2"></i>Lihat Kamar
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Stats Section -->
    <section class="py-5 bg-light">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="text-center">
                        <div class="counter-number fs-1 fw-bold text-warning">150+</div>
                        <h5>Kamar Mewah</h5>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="text-center">
                        <div class="counter-number fs-1 fw-bold text-warning">5000+</div>
                        <h5>Tamu Puas</h5>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="text-center">
                        <div class="counter-number fs-1 fw-bold text-warning">24/7</div>
                        <h5>Layanan</h5>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="text-center">
                        <div class="counter-number fs-1 fw-bold text-warning">5★</div>
                        <h5>Rating</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Rooms Section -->
    

    <!-- Testimonials -->
    <section class="py-5 bg-light">
        <div class="container">
            <h2 class="text-center mb-5 fw-bold section-title">Testimoni Tamu</h2>
            <div class="row">
                <div class="col-md-4">
                    <div class="bg-white p-4 rounded-3 shadow-sm h-100">
                        <div class="mb-3">
                            <i class="fas fa-star text-warning"></i>
                            <i class="fas fa-star text-warning"></i>
                            <i class="fas fa-star text-warning"></i>
                            <i class="fas fa-star text-warning"></i>
                            <i class="fas fa-star text-warning"></i>
                        </div>
                        <p class="mb-3">"Pelayanan yang luar biasa! Staff sangat ramah dan fasilitas hotel sangat lengkap. Pasti akan kembali lagi."</p>
                        <strong>- Sarah Wijaya</strong>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="bg-white p-4 rounded-3 shadow-sm h-100">
                        <div class="mb-3">
                            <i class="fas fa-star text-warning"></i>
                            <i class="fas fa-star text-warning"></i>
                            <i class="fas fa-star text-warning"></i>
                            <i class="fas fa-star text-warning"></i>
                            <i class="fas fa-star text-warning"></i>
                        </div>
                        <p class="mb-3">"Lokasi strategis di pusat kota, kamar bersih dan nyaman. Breakfast buffet-nya juga sangat enak!"</p>
                        <strong>- Budi Santoso</strong>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="bg-white p-4 rounded-3 shadow-sm h-100">
                        <div class="mb-3">
                            <i class="fas fa-star text-warning"></i>
                            <i class="fas fa-star text-warning"></i>
                            <i class="fas fa-star text-warning"></i>
                            <i class="fas fa-star text-warning"></i>
                            <i class="fas fa-star text-warning"></i>
                        </div>
                        <p class="mb-3">"Perfect untuk acara bisnis maupun liburan keluarga. Fasilitas spa-nya juga sangat memuaskan."</p>
                        <strong>- Lisa Putri</strong>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <footer id="contact" class="bg-dark text-white py-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 mb-4">
                    <h5 class="mb-3"><i class="fas fa-hotel me-2"></i>Hotel Agria Bogor</h5>
                    <p>Hotel mewah dengan pelayanan terbaik di jantung kota Bogor. Nikmati pengalaman menginap yang tak terlupakan bersama kami.</p>
                </div>
                <div class="col-lg-4 mb-4">
                    <h5 class="mb-3">Kontak Kami</h5>
                    <p><i class="fas fa-map-marker-alt me-2"></i>Jl. Raya Tajur No.612, RT.02/RW.05, Muarasari, Kec. Bogor Sel., Kota Bogor, Jawa Barat 16145</p>
                    <p><i class="fas fa-phone me-2"></i>02517550700</p>
                    <p><i class="fas fa-envelope me-2"></i>info@agriabogor.com</p>
                </div>
                <div class="col-lg-4 mb-4">
                    <h5 class="mb-3">Ikuti Kami</h5>
                    <div class="d-flex gap-3">
                        <a href="#" class="text-white"><i class="fab fa-facebook fa-2x"></i></a>
                        <a href="#" class="text-white"><i class="fab fa-instagram fa-2x"></i></a>
                        <a href="#" class="text-white"><i class="fab fa-twitter fa-2x"></i></a>
                        <a href="#" class="text-white"><i class="fab fa-linkedin fa-2x"></i></a>
                    </div>
                </div>
            </div>
            <hr class="my-4">
            <div class="text-center">
                <p class="mb-0">&copy; 2025 Hotel Agria Bogor. All rights reserved. | Built with Laravel & Bootstrap</p>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Room prices
        const roomPrices = {
            'Standard': 750000,
            'Deluxe': 1200000,
            'Suite': 2500000
        };

        // Function to book room from room cards
        function bookRoom(roomType) {
            document.getElementById('roomType').value = roomType;
            document.getElementById('booking').scrollIntoView({ behavior: 'smooth' });
            calculateTotal();
        }

        // Function to calculate total price
        function calculateTotal() {
            const roomType = document.getElementById('roomType').value;
            const checkIn = new Date(document.getElementById('checkIn').value);
            const checkOut = new Date(document.getElementById('checkOut').value);
            
            if (roomType && checkIn && checkOut && checkOut > checkIn) {
                const days = Math.ceil((checkOut - checkIn) / (1000 * 60 * 60 * 24));
                const totalPrice = roomPrices[roomType] * days;
                document.getElementById('totalPrice').value = 'Rp ' + totalPrice.toLocaleString('id-ID');
            } else {
                document.getElementById('totalPrice').value = '';
            }
        }

        // Event listeners for price calculation
        document.getElementById('roomType').addEventListener('change', calculateTotal);
        document.getElementById('checkIn').addEventListener('change', calculateTotal);
        document.getElementById('checkOut').addEventListener('change', calculateTotal);

        // Set minimum date to today
        const today = new Date().toISOString().split('T')[0];
        document.getElementById('checkIn').min = today;
        document.getElementById('checkOut').min = today;

        // Update checkout minimum date when checkin changes
        document.getElementById('checkIn').addEventListener('change', function() {
            const checkInDate = this.value;
            document.getElementById('checkOut').min = checkInDate;
        });

        // Form submission
        document.getElementById('bookingForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form data
            const formData = {
                name: document.getElementById('guestName').value,
                email: document.getElementById('email').value,
                phone: document.getElementById('phone').value,
                roomType: document.getElementById('roomType').value,
                checkIn: document.getElementById('checkIn').value,
                checkOut: document.getElementById('checkOut').value,
                guests: document.getElementById('guests').value,
                totalPrice: document.getElementById('totalPrice').value,
                specialRequest: document.getElementById('specialRequest').value
            };

            // Show success message
            const alertDiv = document.getElementById('bookingAlert');
            alertDiv.innerHTML = `
                <div class="alert alert-booking alert-dismissible fade show" role="alert">
                    <i class="fas fa-check-circle me-2"></i>
                    <strong>Pemesanan Berhasil!</strong> 
                    Terima kasih ${formData.name}, pemesanan Anda untuk kamar ${formData.roomType} telah diterima. 
                    Tim kami akan menghubungi Anda segera untuk konfirmasi pembayaran.
                    <br><small>Kode Booking: GP${Date.now().toString().slice(-6)}</small>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert"></button>
                </div>
            `;
            alertDiv.style.display = 'block';

            // Reset form
            this.reset();
            document.getElementById('totalPrice').value = '';

            // Scroll to alert
            alertDiv.scrollIntoView({ behavior: 'smooth' });

            // In real Laravel application, this would send data to backend
            console.log('Booking Data:', formData);
        });

        // Smooth scrolling for navigation links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });

        // Counter animation
        function animateCounters() {
            const counters = document.querySelectorAll('.counter-number');
            counters.forEach(counter => {
                const target = parseInt(counter.textContent.replace(/[^0-9]/g, ''));
                let current = 0;
                const increment = target / 50;
                
                const updateCounter = () => {
                    if (current < target) {
                        current += increment;
                        counter.textContent = Math.ceil(current) + (counter.textContent.includes('+') ? '+' : counter.textContent.includes('★') ? '★' : counter.textContent.includes('/') ? '/7' : '');
                        requestAnimationFrame(updateCounter);
                    } else {
                        counter.textContent = counter.textContent;
                    }
                };
                
                updateCounter();
            });
        }

        // Trigger counter animation when section is visible
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    animateCounters();
                    observer.unobserve(entry.target);
                }
            });
        });

        observer.observe(document.querySelector('.stats-counter').parentElement);

        // Form validation enhancement
        function validateForm() {
            const requiredFields = ['guestName', 'email', 'phone', 'roomType', 'checkIn', 'checkOut', 'guests'];
            let isValid = true;
            
            requiredFields.forEach(fieldId => {
                const field = document.getElementById(fieldId);
                if (!field.value.trim()) {
                    field.classList.add('is-invalid');
                    isValid = false;
                } else {
                    field.classList.remove('is-invalid');
                }
            });
            
            // Email validation
            const email = document.getElementById('email').value;
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (email && !emailRegex.test(email)) {
                document.getElementById('email').classList.add('is-invalid');
                isValid = false;
            }
            
            // Phone validation
            const phone = document.getElementById('phone').value;
            const phoneRegex = /^[0-9+\-\s()]+$/;
            if (phone && !phoneRegex.test(phone)) {
                document.getElementById('phone').classList.add('is-invalid');
                isValid = false;
            }
            
            return isValid;
        }

        // Add real-time validation
        document.querySelectorAll('input, select').forEach(field => {
            field.addEventListener('blur', function() {
                if (this.hasAttribute('required') && !this.value.trim()) {
                    this.classList.add('is-invalid');
                } else {
                    this.classList.remove('is-invalid');
                }
            });
        });

        // Update form submission with validation
        document.getElementById('bookingForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            if (!validateForm()) {
                const alertDiv = document.getElementById('bookingAlert');
                alertDiv.innerHTML = `
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        <strong>Error!</strong> Mohon lengkapi semua field yang diperlukan dengan benar.
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                `;
                alertDiv.style.display = 'block';
                alertDiv.scrollIntoView({ behavior: 'smooth' });
                return;
            }
            
            // Get form data
            const formData = {
                name: document.getElementById('guestName').value,
                email: document.getElementById('email').value,
                phone: document.getElementById('phone').value,
                roomType: document.getElementById('roomType').value,
                checkIn: document.getElementById('checkIn').value,
                checkOut: document.getElementById('checkOut').value,
                guests: document.getElementById('guests').value,
                totalPrice: document.getElementById('totalPrice').value,
                specialRequest: document.getElementById('specialRequest').value
            };

            // Show success message
            const alertDiv = document.getElementById('bookingAlert');
            alertDiv.innerHTML = `
                <div class="alert alert-booking alert-dismissible fade show" role="alert">
                    <i class="fas fa-check-circle me-2"></i>
                    <strong>Pemesanan Berhasil!</strong> 
                    Terima kasih ${formData.name}, pemesanan Anda untuk kamar ${formData.roomType} telah diterima. 
                    Tim kami akan menghubungi Anda segera untuk konfirmasi pembayaran.
                    <br><small>Kode Booking: GP${Date.now().toString().slice(-6)}</small>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert"></button>
                </div>
            `;
            alertDiv.style.display = 'block';

            // Reset form
            this.reset();
            document.getElementById('totalPrice').value = '';

            // Scroll to alert
            alertDiv.scrollIntoView({ behavior: 'smooth' });

            // In real Laravel application, this would send data to backend
            console.log('Booking Data:', formData);
        });
    </script>
</body>
</html>